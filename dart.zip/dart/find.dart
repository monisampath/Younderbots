void main(){
  List<int> num=[1,2,4,5];
  int n=5;
  int totalSum=(n*(n+1))~/2;
  int actualSum=num.reduce((a,b) => a+b);
  int missing=totalSum-actualSum;
print("Missing number:$missing");
}