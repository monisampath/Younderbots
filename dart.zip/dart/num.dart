void main(){
    List<int> nums=[1,2,2,3,4,4,5];
    List<int> result=nums.toSet().toList();
    print(result);
}