package com.example.value

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
