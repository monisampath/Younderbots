void main(){
  List<int> nums=[10,9,3,4,5,6,7,13];
  List<int> uniqueNums=nums.toSet().toList();
  uniqueNums.sort((a,b) => b.compareTo(a));
  int largest=uniqueNums[0];
  int secondlargest=uniqueNums[1];
  int sum=largest+secondlargest;
  print("Larges:$largest");
  print("Second Largest:$secondlargest");
  print("sum:$sum");
}