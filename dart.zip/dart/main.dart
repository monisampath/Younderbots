void main(){
    String str="flesruoYevileB";
    String res="";
    for(int i=str.length-1;i>=0;i--){
      res=res+str[i];
    }
    print(res);
}

