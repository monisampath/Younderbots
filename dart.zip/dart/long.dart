import 'dart:ffi';

void main(){
  String s="abcabcbb";
  int maxLen=0;
  String longest=" ";
  int start=0;
  Map<String,int> seen={};
  for(int i=0;i<s.length;i++){
    if(seen.containsKey(s[i])&&seen[s[i]]!>=start){
      start=seen[s[i]]!+1;

    }
    seen[s[i]]=i;
    if(i-start+1>maxLen){
      maxLen=i-start+1;
      longest=s.substring(start,i+1);
    }
  }
  print("Longest substring without repeating character:$longest");
  print("Length:$maxLen");

}