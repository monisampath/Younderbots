void main(){
    int num=641108;
    int sum=0;
    while(num>0){
        sum+=num%10;
        num~/=10;
    }
    print("Sum of the digit:$sum");
}