bool isSubsetSum(List<int> arr,int n,int sum){
  if(sum==0)return true;
  if(n==0 && sum!=0)return false;
  if(arr[n-1]>sum){
    return isSubsetSum(arr,n-1,sum);

  }
  return isSubsetSum(arr,n-1,sum)||isSubsetSum(arr,n-1,sum-arr[n-1]);
}
void main(){
  List<int>arr=[3,34,4,12,5,2];
  int sum1=9;
  int sum2=30;
  print("Input:sum=$sum1->${isSubsetSum(arr,arr.length,sum1)}");
  print("Input:sum=$sum2->${isSubsetSum(arr,arr.length,sum2)}");
}