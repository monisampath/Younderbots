void main() {
  List<int> nums = [1, 1, 2];
  List<List<int>> result = permuteUnique(nums);
  for (var perm in result) {
    print(perm);
  }
}

List<List<int>> permuteUnique(List<int> nums) {
  List<List<int>> result = [];
  nums.sort(); // Sort to handle duplicates
  List<bool> used = List.filled(nums.length, false);
  backtrack(nums, [], used, result);
  return result;
}

void backtrack(List<int> nums, List<int> current, List<bool> used, List<List<int>> result) {
  if (current.length == nums.length) {
    result.add(List.from(current)); // Add a copy
    return;
  }

  for (int i = 0; i < nums.length; i++) {
    if (used[i]) continue;

    // Skip duplicates
    if (i > 0 && nums[i] == nums[i - 1] && !used[i - 1]) continue;

    used[i] = true;
    current.add(nums[i]);

    backtrack(nums, current, used, result);

    // Backtrack
    used[i] = false;
    current.removeLast();
  }
}
