void main() {
  String input = 'b3c6d15';
  print(expandString(input));
}

String expandString(String input) {
  StringBuffer result = StringBuffer();
  RegExp regExp = RegExp(r'([a-zA-Z])(\d{1,2})');

  for (final match in regExp.allMatches(input)) {
    String char = match.group(1)!;
    int count = int.parse(match.group(2)!);
    result.write(char * count);
  }

  return result.toString();
}
